require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({
        error: "الموقع جاهز، لكن لازم تضيف مفتاح API داخل ملف .env حتى يشتغل الذكاء الاصطناعي."
      });
    }

    const messages = req.body && req.body.messages;
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "اكتب رسالة أولاً." });
    }

    const safeMessages = messages.slice(-20).map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 6000)
    })).filter((m) => m.content.trim());

    if (!safeMessages.length) {
      return res.status(400).json({ error: "الرسالة فارغة." });
    }

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          {
            role: "system",
            content: "أنت مساعد ذكاء اصطناعي مفيد وواضح. أجب باللغة التي يستخدمها الشخص، وادعم العربية واللهجة العراقية عند الحاجة. ساعد في التعلم والكتابة والبرمجة والمهام اليومية، ولا تساعد في الإيذاء أو الجرائم."
          },
          ...safeMessages
        ]
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const message = data?.error?.message || "تعذر الاتصال بخدمة الذكاء الاصطناعي.";
      return res.status(response.status === 429 ? 429 : 502).json({ error: message });
    }

    const answer = data?.choices?.[0]?.message?.content;
    if (!answer) return res.status(502).json({ error: "وصل رد غير متوقع من الخدمة." });
    res.json({ answer });
  } catch (error) {
    console.error("Chat error:", error.message);
    res.status(500).json({ error: "صار خطأ بالسيرفر. تأكد من الاتصال والإعدادات." });
  }
});

app.listen(PORT, () => {
  console.log(`WormGPT AI is running at http://localhost:${PORT}`);
});