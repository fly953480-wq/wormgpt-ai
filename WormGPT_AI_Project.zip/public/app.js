const form = document.getElementById("chatForm");
const input = document.getElementById("userInput");
const messagesEl = document.getElementById("messages");
const welcome = document.getElementById("welcome");
const sendBtn = document.getElementById("sendBtn");
const historyEl = document.getElementById("history");
const statusText = document.getElementById("statusText");
const sidebar = document.getElementById("sidebar");
let messages = [];
let savedChats = [];

function addMessage(role, text, extraClass = "") {
  if (role === "user") welcome.hidden = true;
  const row = document.createElement("div");
  row.className = `message ${role} ${extraClass}`.trim();
  if (role === "assistant") {
    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = "W";
    row.appendChild(avatar);
  }
  const body = document.createElement("div");
  body.className = "message-text";
  body.textContent = text;
  row.appendChild(body);
  messagesEl.appendChild(row);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return { row, body };
}

function newChat() {
  if (messages.length) {
    const firstUser = messages.find(m => m.role === "user");
    if (firstUser) {
      savedChats.unshift({ title: firstUser.content.slice(0, 35), messages: [...messages] });
      savedChats = savedChats.slice(0, 8);
      renderHistory();
    }
  }
  messages = [];
  messagesEl.replaceChildren();
  welcome.hidden = false;
  input.value = "";
  input.focus();
  sidebar.classList.remove("open");
}

function renderHistory() {
  historyEl.replaceChildren();
  if (!savedChats.length) {
    const empty = document.createElement("div");
    empty.className = "history-empty";
    empty.textContent = "محادثتك الحالية تظهر هنا";
    historyEl.appendChild(empty);
    return;
  }
  savedChats.forEach((chat) => {
    const item = document.createElement("div");
    item.className = "history-item";
    item.textContent = "◌  " + chat.title;
    item.title = chat.title;
    item.addEventListener("click", () => {
      messages = [...chat.messages];
      messagesEl.replaceChildren();
      welcome.hidden = true;
      messages.forEach(m => addMessage(m.role, m.content));
      sidebar.classList.remove("open");
    });
    historyEl.appendChild(item);
  });
}

async function sendMessage(text) {
  const content = (text ?? input.value).trim();
  if (!content || sendBtn.disabled) return;
  input.value = "";
  input.style.height = "auto";
  messages.push({ role: "user", content });
  addMessage("user", content);
  const pending = addMessage("assistant", "جاري التفكير...", "typing");
  pending.body.classList.add("typing");
  sendBtn.disabled = true;

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "تعذر الحصول على رد.");
    pending.body.textContent = data.answer;
    pending.body.classList.remove("typing");
    messages.push({ role: "assistant", content: data.answer });
    statusText.textContent = "متصل بالخدمة";
  } catch (err) {
    pending.body.textContent = err.message || "صار خطأ بالاتصال.";
    pending.body.classList.remove("typing");
    pending.row.classList.add("error");
    statusText.textContent = "تحقق من إعداد API";
  } finally {
    pending.row.classList.remove("typing");
    sendBtn.disabled = false;
    input.focus();
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage();
});
input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});
input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 160) + "px";
});
document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => {
    input.value = button.dataset.prompt;
    input.focus();
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 160) + "px";
  });
});
document.getElementById("newChatBtn").addEventListener("click", newChat);
document.getElementById("clearBtn").addEventListener("click", newChat);
document.getElementById("menuBtn").addEventListener("click", () => sidebar.classList.toggle("open"));
document.getElementById("focusBtn").addEventListener("click", () => {
  input.value = "اقترح عليّ أفكاراً مفيدة أقدر أتعلمها اليوم.";
  input.focus();
});
document.getElementById("toolsBtn").addEventListener("click", () => {
  document.querySelector(".right-panel")?.scrollIntoView({ behavior: "smooth" });
  input.value = "شنو الأدوات اللي تگدر تساعدني بيها؟";
  input.focus();
});
fetch("/api/health").then(r => r.json()).then(data => {
  statusText.textContent = data.configured ? "جاهز للمحادثة" : "أضف مفتاح API";
}).catch(() => { statusText.textContent = "شغّل السيرفر أولاً"; });
